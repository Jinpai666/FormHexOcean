# Hexocan Michal Kowalewski

# versions
Node v18.12.1</br>
npm  9.1.1

# To set up the project run:
1 npm install</br>
2. npm run dev

# Time the project took:
approximately 13 hours, </br>
It was my first contact with Redux Form, although it says on its website not to begin a project as the author of Redux Form has written a superior library. However, I used it as required in the assignment.

# Link to live website
https://hexocean.netlify.app/

# Link to repository
https://github.com/Jinpai666/FormHexOcean
